"# my-webpack-module" 
